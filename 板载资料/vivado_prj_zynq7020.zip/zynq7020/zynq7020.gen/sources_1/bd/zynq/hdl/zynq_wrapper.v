//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2022.2 (win64) Build 3671981 Fri Oct 14 05:00:03 MDT 2022
//Date        : Tue Jul  1 16:09:24 2025
//Host        : DESKTOP-KQDT6HQ running 64-bit major release  (build 9200)
//Command     : generate_target zynq_wrapper.bd
//Design      : zynq_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module zynq_wrapper
   (ADCDAT,
    ADCLRC,
    BCLK,
    CAN_rx,
    CAN_tx,
    DACDAT,
    DACLRC,
    DDR_addr,
    DDR_ba,
    DDR_cas_n,
    DDR_ck_n,
    DDR_ck_p,
    DDR_cke,
    DDR_cs_n,
    DDR_dm,
    DDR_dq,
    DDR_dqs_n,
    DDR_dqs_p,
    DDR_odt,
    DDR_ras_n,
    DDR_reset_n,
    DDR_we_n,
    ETH1_MDIO_mdc,
    ETH1_MDIO_mdio_io,
    ETH1_RGMII_rd,
    ETH1_RGMII_rx_ctl,
    ETH1_RGMII_rxc,
    ETH1_RGMII_td,
    ETH1_RGMII_tx_ctl,
    ETH1_RGMII_txc,
    FIXED_IO_ddr_vrn,
    FIXED_IO_ddr_vrp,
    FIXED_IO_mio,
    FIXED_IO_ps_clk,
    FIXED_IO_ps_porb,
    FIXED_IO_ps_srstb,
    GPIO_0_0_tri_io,
    I2C1_scl_io,
    I2C1_sda_io,
    I2C2_scl_io,
    I2C2_sda_io,
    I2C3_scl_io,
    I2C3_sda_io,
    MCLK,
    RS232_rxd,
    RS232_txd,
    RS485_rxd,
    RS485_txd,
    TMDS_0_tmds_clk_n,
    TMDS_0_tmds_clk_p,
    TMDS_0_tmds_data_n,
    TMDS_0_tmds_data_p,
    beep,
    fan,
    lcd_bl,
    lcd_de_0,
    lcd_hs_0,
    lcd_pclk_0,
    lcd_vs_0,
    ov5640_data_0,
    ov5640_href,
    ov5640_pclk,
    ov5640_vsync,
    rgb_tft_0);
  input ADCDAT;
  output ADCLRC;
  output [0:0]BCLK;
  input CAN_rx;
  output CAN_tx;
  output DACDAT;
  output DACLRC;
  inout [14:0]DDR_addr;
  inout [2:0]DDR_ba;
  inout DDR_cas_n;
  inout DDR_ck_n;
  inout DDR_ck_p;
  inout DDR_cke;
  inout DDR_cs_n;
  inout [3:0]DDR_dm;
  inout [31:0]DDR_dq;
  inout [3:0]DDR_dqs_n;
  inout [3:0]DDR_dqs_p;
  inout DDR_odt;
  inout DDR_ras_n;
  inout DDR_reset_n;
  inout DDR_we_n;
  output ETH1_MDIO_mdc;
  inout ETH1_MDIO_mdio_io;
  input [3:0]ETH1_RGMII_rd;
  input ETH1_RGMII_rx_ctl;
  input ETH1_RGMII_rxc;
  output [3:0]ETH1_RGMII_td;
  output ETH1_RGMII_tx_ctl;
  output ETH1_RGMII_txc;
  inout FIXED_IO_ddr_vrn;
  inout FIXED_IO_ddr_vrp;
  inout [53:0]FIXED_IO_mio;
  inout FIXED_IO_ps_clk;
  inout FIXED_IO_ps_porb;
  inout FIXED_IO_ps_srstb;
  inout [15:0]GPIO_0_0_tri_io;
  inout I2C1_scl_io;
  inout I2C1_sda_io;
  inout I2C2_scl_io;
  inout I2C2_sda_io;
  inout I2C3_scl_io;
  inout I2C3_sda_io;
  output MCLK;
  input RS232_rxd;
  output RS232_txd;
  input RS485_rxd;
  output RS485_txd;
  output TMDS_0_tmds_clk_n;
  output TMDS_0_tmds_clk_p;
  output [2:0]TMDS_0_tmds_data_n;
  output [2:0]TMDS_0_tmds_data_p;
  output beep;
  output fan;
  output lcd_bl;
  output lcd_de_0;
  output lcd_hs_0;
  output lcd_pclk_0;
  output lcd_vs_0;
  input [7:0]ov5640_data_0;
  input ov5640_href;
  input ov5640_pclk;
  input ov5640_vsync;
  output [23:0]rgb_tft_0;

  wire ADCDAT;
  wire ADCLRC;
  wire [0:0]BCLK;
  wire CAN_rx;
  wire CAN_tx;
  wire DACDAT;
  wire DACLRC;
  wire [14:0]DDR_addr;
  wire [2:0]DDR_ba;
  wire DDR_cas_n;
  wire DDR_ck_n;
  wire DDR_ck_p;
  wire DDR_cke;
  wire DDR_cs_n;
  wire [3:0]DDR_dm;
  wire [31:0]DDR_dq;
  wire [3:0]DDR_dqs_n;
  wire [3:0]DDR_dqs_p;
  wire DDR_odt;
  wire DDR_ras_n;
  wire DDR_reset_n;
  wire DDR_we_n;
  wire ETH1_MDIO_mdc;
  wire ETH1_MDIO_mdio_i;
  wire ETH1_MDIO_mdio_io;
  wire ETH1_MDIO_mdio_o;
  wire ETH1_MDIO_mdio_t;
  wire [3:0]ETH1_RGMII_rd;
  wire ETH1_RGMII_rx_ctl;
  wire ETH1_RGMII_rxc;
  wire [3:0]ETH1_RGMII_td;
  wire ETH1_RGMII_tx_ctl;
  wire ETH1_RGMII_txc;
  wire FIXED_IO_ddr_vrn;
  wire FIXED_IO_ddr_vrp;
  wire [53:0]FIXED_IO_mio;
  wire FIXED_IO_ps_clk;
  wire FIXED_IO_ps_porb;
  wire FIXED_IO_ps_srstb;
  wire [0:0]GPIO_0_0_tri_i_0;
  wire [1:1]GPIO_0_0_tri_i_1;
  wire [10:10]GPIO_0_0_tri_i_10;
  wire [11:11]GPIO_0_0_tri_i_11;
  wire [12:12]GPIO_0_0_tri_i_12;
  wire [13:13]GPIO_0_0_tri_i_13;
  wire [14:14]GPIO_0_0_tri_i_14;
  wire [15:15]GPIO_0_0_tri_i_15;
  wire [2:2]GPIO_0_0_tri_i_2;
  wire [3:3]GPIO_0_0_tri_i_3;
  wire [4:4]GPIO_0_0_tri_i_4;
  wire [5:5]GPIO_0_0_tri_i_5;
  wire [6:6]GPIO_0_0_tri_i_6;
  wire [7:7]GPIO_0_0_tri_i_7;
  wire [8:8]GPIO_0_0_tri_i_8;
  wire [9:9]GPIO_0_0_tri_i_9;
  wire [0:0]GPIO_0_0_tri_io_0;
  wire [1:1]GPIO_0_0_tri_io_1;
  wire [10:10]GPIO_0_0_tri_io_10;
  wire [11:11]GPIO_0_0_tri_io_11;
  wire [12:12]GPIO_0_0_tri_io_12;
  wire [13:13]GPIO_0_0_tri_io_13;
  wire [14:14]GPIO_0_0_tri_io_14;
  wire [15:15]GPIO_0_0_tri_io_15;
  wire [2:2]GPIO_0_0_tri_io_2;
  wire [3:3]GPIO_0_0_tri_io_3;
  wire [4:4]GPIO_0_0_tri_io_4;
  wire [5:5]GPIO_0_0_tri_io_5;
  wire [6:6]GPIO_0_0_tri_io_6;
  wire [7:7]GPIO_0_0_tri_io_7;
  wire [8:8]GPIO_0_0_tri_io_8;
  wire [9:9]GPIO_0_0_tri_io_9;
  wire [0:0]GPIO_0_0_tri_o_0;
  wire [1:1]GPIO_0_0_tri_o_1;
  wire [10:10]GPIO_0_0_tri_o_10;
  wire [11:11]GPIO_0_0_tri_o_11;
  wire [12:12]GPIO_0_0_tri_o_12;
  wire [13:13]GPIO_0_0_tri_o_13;
  wire [14:14]GPIO_0_0_tri_o_14;
  wire [15:15]GPIO_0_0_tri_o_15;
  wire [2:2]GPIO_0_0_tri_o_2;
  wire [3:3]GPIO_0_0_tri_o_3;
  wire [4:4]GPIO_0_0_tri_o_4;
  wire [5:5]GPIO_0_0_tri_o_5;
  wire [6:6]GPIO_0_0_tri_o_6;
  wire [7:7]GPIO_0_0_tri_o_7;
  wire [8:8]GPIO_0_0_tri_o_8;
  wire [9:9]GPIO_0_0_tri_o_9;
  wire [0:0]GPIO_0_0_tri_t_0;
  wire [1:1]GPIO_0_0_tri_t_1;
  wire [10:10]GPIO_0_0_tri_t_10;
  wire [11:11]GPIO_0_0_tri_t_11;
  wire [12:12]GPIO_0_0_tri_t_12;
  wire [13:13]GPIO_0_0_tri_t_13;
  wire [14:14]GPIO_0_0_tri_t_14;
  wire [15:15]GPIO_0_0_tri_t_15;
  wire [2:2]GPIO_0_0_tri_t_2;
  wire [3:3]GPIO_0_0_tri_t_3;
  wire [4:4]GPIO_0_0_tri_t_4;
  wire [5:5]GPIO_0_0_tri_t_5;
  wire [6:6]GPIO_0_0_tri_t_6;
  wire [7:7]GPIO_0_0_tri_t_7;
  wire [8:8]GPIO_0_0_tri_t_8;
  wire [9:9]GPIO_0_0_tri_t_9;
  wire I2C1_scl_i;
  wire I2C1_scl_io;
  wire I2C1_scl_o;
  wire I2C1_scl_t;
  wire I2C1_sda_i;
  wire I2C1_sda_io;
  wire I2C1_sda_o;
  wire I2C1_sda_t;
  wire I2C2_scl_i;
  wire I2C2_scl_io;
  wire I2C2_scl_o;
  wire I2C2_scl_t;
  wire I2C2_sda_i;
  wire I2C2_sda_io;
  wire I2C2_sda_o;
  wire I2C2_sda_t;
  wire I2C3_scl_i;
  wire I2C3_scl_io;
  wire I2C3_scl_o;
  wire I2C3_scl_t;
  wire I2C3_sda_i;
  wire I2C3_sda_io;
  wire I2C3_sda_o;
  wire I2C3_sda_t;
  wire MCLK;
  wire RS232_rxd;
  wire RS232_txd;
  wire RS485_rxd;
  wire RS485_txd;
  wire TMDS_0_tmds_clk_n;
  wire TMDS_0_tmds_clk_p;
  wire [2:0]TMDS_0_tmds_data_n;
  wire [2:0]TMDS_0_tmds_data_p;
  wire beep;
  wire fan;
  wire lcd_bl;
  wire lcd_de_0;
  wire lcd_hs_0;
  wire lcd_pclk_0;
  wire lcd_vs_0;
  wire [7:0]ov5640_data_0;
  wire ov5640_href;
  wire ov5640_pclk;
  wire ov5640_vsync;
  wire [23:0]rgb_tft_0;

  IOBUF ETH1_MDIO_mdio_iobuf
       (.I(ETH1_MDIO_mdio_o),
        .IO(ETH1_MDIO_mdio_io),
        .O(ETH1_MDIO_mdio_i),
        .T(ETH1_MDIO_mdio_t));
  IOBUF GPIO_0_0_tri_iobuf_0
       (.I(GPIO_0_0_tri_o_0),
        .IO(GPIO_0_0_tri_io[0]),
        .O(GPIO_0_0_tri_i_0),
        .T(GPIO_0_0_tri_t_0));
  IOBUF GPIO_0_0_tri_iobuf_1
       (.I(GPIO_0_0_tri_o_1),
        .IO(GPIO_0_0_tri_io[1]),
        .O(GPIO_0_0_tri_i_1),
        .T(GPIO_0_0_tri_t_1));
  IOBUF GPIO_0_0_tri_iobuf_10
       (.I(GPIO_0_0_tri_o_10),
        .IO(GPIO_0_0_tri_io[10]),
        .O(GPIO_0_0_tri_i_10),
        .T(GPIO_0_0_tri_t_10));
  IOBUF GPIO_0_0_tri_iobuf_11
       (.I(GPIO_0_0_tri_o_11),
        .IO(GPIO_0_0_tri_io[11]),
        .O(GPIO_0_0_tri_i_11),
        .T(GPIO_0_0_tri_t_11));
  IOBUF GPIO_0_0_tri_iobuf_12
       (.I(GPIO_0_0_tri_o_12),
        .IO(GPIO_0_0_tri_io[12]),
        .O(GPIO_0_0_tri_i_12),
        .T(GPIO_0_0_tri_t_12));
  IOBUF GPIO_0_0_tri_iobuf_13
       (.I(GPIO_0_0_tri_o_13),
        .IO(GPIO_0_0_tri_io[13]),
        .O(GPIO_0_0_tri_i_13),
        .T(GPIO_0_0_tri_t_13));
  IOBUF GPIO_0_0_tri_iobuf_14
       (.I(GPIO_0_0_tri_o_14),
        .IO(GPIO_0_0_tri_io[14]),
        .O(GPIO_0_0_tri_i_14),
        .T(GPIO_0_0_tri_t_14));
  IOBUF GPIO_0_0_tri_iobuf_15
       (.I(GPIO_0_0_tri_o_15),
        .IO(GPIO_0_0_tri_io[15]),
        .O(GPIO_0_0_tri_i_15),
        .T(GPIO_0_0_tri_t_15));
  IOBUF GPIO_0_0_tri_iobuf_2
       (.I(GPIO_0_0_tri_o_2),
        .IO(GPIO_0_0_tri_io[2]),
        .O(GPIO_0_0_tri_i_2),
        .T(GPIO_0_0_tri_t_2));
  IOBUF GPIO_0_0_tri_iobuf_3
       (.I(GPIO_0_0_tri_o_3),
        .IO(GPIO_0_0_tri_io[3]),
        .O(GPIO_0_0_tri_i_3),
        .T(GPIO_0_0_tri_t_3));
  IOBUF GPIO_0_0_tri_iobuf_4
       (.I(GPIO_0_0_tri_o_4),
        .IO(GPIO_0_0_tri_io[4]),
        .O(GPIO_0_0_tri_i_4),
        .T(GPIO_0_0_tri_t_4));
  IOBUF GPIO_0_0_tri_iobuf_5
       (.I(GPIO_0_0_tri_o_5),
        .IO(GPIO_0_0_tri_io[5]),
        .O(GPIO_0_0_tri_i_5),
        .T(GPIO_0_0_tri_t_5));
  IOBUF GPIO_0_0_tri_iobuf_6
       (.I(GPIO_0_0_tri_o_6),
        .IO(GPIO_0_0_tri_io[6]),
        .O(GPIO_0_0_tri_i_6),
        .T(GPIO_0_0_tri_t_6));
  IOBUF GPIO_0_0_tri_iobuf_7
       (.I(GPIO_0_0_tri_o_7),
        .IO(GPIO_0_0_tri_io[7]),
        .O(GPIO_0_0_tri_i_7),
        .T(GPIO_0_0_tri_t_7));
  IOBUF GPIO_0_0_tri_iobuf_8
       (.I(GPIO_0_0_tri_o_8),
        .IO(GPIO_0_0_tri_io[8]),
        .O(GPIO_0_0_tri_i_8),
        .T(GPIO_0_0_tri_t_8));
  IOBUF GPIO_0_0_tri_iobuf_9
       (.I(GPIO_0_0_tri_o_9),
        .IO(GPIO_0_0_tri_io[9]),
        .O(GPIO_0_0_tri_i_9),
        .T(GPIO_0_0_tri_t_9));
  IOBUF I2C1_scl_iobuf
       (.I(I2C1_scl_o),
        .IO(I2C1_scl_io),
        .O(I2C1_scl_i),
        .T(I2C1_scl_t));
  IOBUF I2C1_sda_iobuf
       (.I(I2C1_sda_o),
        .IO(I2C1_sda_io),
        .O(I2C1_sda_i),
        .T(I2C1_sda_t));
  IOBUF I2C2_scl_iobuf
       (.I(I2C2_scl_o),
        .IO(I2C2_scl_io),
        .O(I2C2_scl_i),
        .T(I2C2_scl_t));
  IOBUF I2C2_sda_iobuf
       (.I(I2C2_sda_o),
        .IO(I2C2_sda_io),
        .O(I2C2_sda_i),
        .T(I2C2_sda_t));
  IOBUF I2C3_scl_iobuf
       (.I(I2C3_scl_o),
        .IO(I2C3_scl_io),
        .O(I2C3_scl_i),
        .T(I2C3_scl_t));
  IOBUF I2C3_sda_iobuf
       (.I(I2C3_sda_o),
        .IO(I2C3_sda_io),
        .O(I2C3_sda_i),
        .T(I2C3_sda_t));
  zynq zynq_i
       (.ADCDAT(ADCDAT),
        .ADCLRC(ADCLRC),
        .BCLK(BCLK),
        .CAN_rx(CAN_rx),
        .CAN_tx(CAN_tx),
        .DACDAT(DACDAT),
        .DACLRC(DACLRC),
        .DDR_addr(DDR_addr),
        .DDR_ba(DDR_ba),
        .DDR_cas_n(DDR_cas_n),
        .DDR_ck_n(DDR_ck_n),
        .DDR_ck_p(DDR_ck_p),
        .DDR_cke(DDR_cke),
        .DDR_cs_n(DDR_cs_n),
        .DDR_dm(DDR_dm),
        .DDR_dq(DDR_dq),
        .DDR_dqs_n(DDR_dqs_n),
        .DDR_dqs_p(DDR_dqs_p),
        .DDR_odt(DDR_odt),
        .DDR_ras_n(DDR_ras_n),
        .DDR_reset_n(DDR_reset_n),
        .DDR_we_n(DDR_we_n),
        .ETH1_MDIO_mdc(ETH1_MDIO_mdc),
        .ETH1_MDIO_mdio_i(ETH1_MDIO_mdio_i),
        .ETH1_MDIO_mdio_o(ETH1_MDIO_mdio_o),
        .ETH1_MDIO_mdio_t(ETH1_MDIO_mdio_t),
        .ETH1_RGMII_rd(ETH1_RGMII_rd),
        .ETH1_RGMII_rx_ctl(ETH1_RGMII_rx_ctl),
        .ETH1_RGMII_rxc(ETH1_RGMII_rxc),
        .ETH1_RGMII_td(ETH1_RGMII_td),
        .ETH1_RGMII_tx_ctl(ETH1_RGMII_tx_ctl),
        .ETH1_RGMII_txc(ETH1_RGMII_txc),
        .FIXED_IO_ddr_vrn(FIXED_IO_ddr_vrn),
        .FIXED_IO_ddr_vrp(FIXED_IO_ddr_vrp),
        .FIXED_IO_mio(FIXED_IO_mio),
        .FIXED_IO_ps_clk(FIXED_IO_ps_clk),
        .FIXED_IO_ps_porb(FIXED_IO_ps_porb),
        .FIXED_IO_ps_srstb(FIXED_IO_ps_srstb),
        .GPIO_0_0_tri_i({GPIO_0_0_tri_i_15,GPIO_0_0_tri_i_14,GPIO_0_0_tri_i_13,GPIO_0_0_tri_i_12,GPIO_0_0_tri_i_11,GPIO_0_0_tri_i_10,GPIO_0_0_tri_i_9,GPIO_0_0_tri_i_8,GPIO_0_0_tri_i_7,GPIO_0_0_tri_i_6,GPIO_0_0_tri_i_5,GPIO_0_0_tri_i_4,GPIO_0_0_tri_i_3,GPIO_0_0_tri_i_2,GPIO_0_0_tri_i_1,GPIO_0_0_tri_i_0}),
        .GPIO_0_0_tri_o({GPIO_0_0_tri_o_15,GPIO_0_0_tri_o_14,GPIO_0_0_tri_o_13,GPIO_0_0_tri_o_12,GPIO_0_0_tri_o_11,GPIO_0_0_tri_o_10,GPIO_0_0_tri_o_9,GPIO_0_0_tri_o_8,GPIO_0_0_tri_o_7,GPIO_0_0_tri_o_6,GPIO_0_0_tri_o_5,GPIO_0_0_tri_o_4,GPIO_0_0_tri_o_3,GPIO_0_0_tri_o_2,GPIO_0_0_tri_o_1,GPIO_0_0_tri_o_0}),
        .GPIO_0_0_tri_t({GPIO_0_0_tri_t_15,GPIO_0_0_tri_t_14,GPIO_0_0_tri_t_13,GPIO_0_0_tri_t_12,GPIO_0_0_tri_t_11,GPIO_0_0_tri_t_10,GPIO_0_0_tri_t_9,GPIO_0_0_tri_t_8,GPIO_0_0_tri_t_7,GPIO_0_0_tri_t_6,GPIO_0_0_tri_t_5,GPIO_0_0_tri_t_4,GPIO_0_0_tri_t_3,GPIO_0_0_tri_t_2,GPIO_0_0_tri_t_1,GPIO_0_0_tri_t_0}),
        .I2C1_scl_i(I2C1_scl_i),
        .I2C1_scl_o(I2C1_scl_o),
        .I2C1_scl_t(I2C1_scl_t),
        .I2C1_sda_i(I2C1_sda_i),
        .I2C1_sda_o(I2C1_sda_o),
        .I2C1_sda_t(I2C1_sda_t),
        .I2C2_scl_i(I2C2_scl_i),
        .I2C2_scl_o(I2C2_scl_o),
        .I2C2_scl_t(I2C2_scl_t),
        .I2C2_sda_i(I2C2_sda_i),
        .I2C2_sda_o(I2C2_sda_o),
        .I2C2_sda_t(I2C2_sda_t),
        .I2C3_scl_i(I2C3_scl_i),
        .I2C3_scl_o(I2C3_scl_o),
        .I2C3_scl_t(I2C3_scl_t),
        .I2C3_sda_i(I2C3_sda_i),
        .I2C3_sda_o(I2C3_sda_o),
        .I2C3_sda_t(I2C3_sda_t),
        .MCLK(MCLK),
        .RS232_rxd(RS232_rxd),
        .RS232_txd(RS232_txd),
        .RS485_rxd(RS485_rxd),
        .RS485_txd(RS485_txd),
        .TMDS_0_tmds_clk_n(TMDS_0_tmds_clk_n),
        .TMDS_0_tmds_clk_p(TMDS_0_tmds_clk_p),
        .TMDS_0_tmds_data_n(TMDS_0_tmds_data_n),
        .TMDS_0_tmds_data_p(TMDS_0_tmds_data_p),
        .beep(beep),
        .fan(fan),
        .lcd_bl(lcd_bl),
        .lcd_de_0(lcd_de_0),
        .lcd_hs_0(lcd_hs_0),
        .lcd_pclk_0(lcd_pclk_0),
        .lcd_vs_0(lcd_vs_0),
        .ov5640_data_0(ov5640_data_0),
        .ov5640_href(ov5640_href),
        .ov5640_pclk(ov5640_pclk),
        .ov5640_vsync(ov5640_vsync),
        .rgb_tft_0(rgb_tft_0));
endmodule
